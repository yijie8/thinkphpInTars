
# 简介
让thinkphp框架欢快的跑在tars里面
* 支持打包发布
* 支持服务存活上报（服务注册）



# 使用

* Clone 项目
* 安装依赖 `composer install`
* 打包 `composer run-script deploy`
* 上传tars平台

# 配置说明

* 服务名需要在 ./tars/tars.proto.php 里面正确配置
* 不使用tars平台下发的端口号,按照thinkphp的方式配置

